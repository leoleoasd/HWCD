//
// Created by Leo on 2022/10/22.
//

#ifndef HWCD_ECAL_HTTP_H_
#define HWCD_ECAL_HTTP_H_

void http_init();

#endif // HWCD_ECAL_HTTP_H_
