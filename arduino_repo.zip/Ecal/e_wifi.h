//
// Created by Leo on 2022/10/22.
//

#ifndef HWCD_INCLUDE_E_WIFI_H_
#define HWCD_INCLUDE_E_WIFI_H_

void wifi_init_softap();
void wifi_init_station();
void wifi_init();

#endif // HWCD_INCLUDE_E_WIFI_H_
